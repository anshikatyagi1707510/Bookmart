export type FormInputs = {
  id: string;
  title: string;
  author: string;
  cover: string;
  publicationDate: string;
  description: string;
};
