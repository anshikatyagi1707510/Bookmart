export const API_URL = 'https://my-json-server.typicode.com/cutamar/mock/books';
export const PDF_URL =
  'https://www.antennahouse.com/hubfs/xsl-fo-sample/pdf/basic-link-1.pdf';
// Use the below file for bigger pdf
// 'https://cloud.appwrite.io/v1/storage/buckets/669814c50032c5a6d799/files/669814ea00065c9d1575/view?project=667a99df00019970bc0f&mode=admin';

export const GIT_REPO_URL = 'https://github.com/junaid7lone/bookmart';
export const DEFAULT_PAGINATION_SIZE = 5;
